// function for ALERT BOX

document.getElementById("btn1").addEventListener("click", function () {
  alert("This is an ALERT BOX By Suman Gangopadhyay for Guvi Python Selenium");
});

// function for CONFIRM BOX

document.getElementById("btn2").addEventListener("click", function () {
 
  if (confirm("Is your Name Suman Gangoapdhyay ?")) {
    let data = "YES ! My Nam is Suman Gangopadhyay and I live in Bangalore !";
    document.getElementById("info").innerHTML = data;
  } else {
    let data = "NO !!! You are Wrong !";
    document.getElementById("info").innerHTML = data;
  }
  
});
